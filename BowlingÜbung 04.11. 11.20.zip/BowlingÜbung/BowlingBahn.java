public class BowlingBahn
{
    private List<Kugel> kugeln;

    public BowlingBahn(int AnzahlKugeln){

    }

    public Kugel kugelHinzufuegen(){
        int tmp = (int) (Math.random()*3);
        if(tmp == 0){
            kugeln.Kugel(pFarbe);   
        }
        else if(tmp == 1){
            Kugel();
        }
        else if(tmp == 2){

        }
        return null;   
    }
}
