public class Kugel
{
    private int gewicht;
    private String farbe;
    
    public Kugel(String pFarbe){
        if(pFarbe.equals("Blau")){
            farbe = pFarbe;
            gewicht = 10;
        }
        else if(pFarbe.equals("Gelb")){
            farbe = pFarbe;
            gewicht = 8;
        }
        else if(pFarbe.equals("Rosa")){
            farbe = pFarbe;
            gewicht = 6;
        }
    }
    
    public String getFarbe(){
     return farbe;   
    }
}
